export CUDA_VISIBLE_DEVICES=2

model_name=TDCNet

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh1.csv \
  --model_id ETTh1_720_96 \
  --model $model_name \
  --data ETTh1 \
  --features S \
  --seq_len 720 \
  --label_len 96 \
  --pred_len 96 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 1 \
  --dec_in 1 \
  --c_out 1 \
  --d_model 48 \
  --d_ff 48 \
  --des 'Exp' \
  --itr 1 \
  --top_k 5 \
  --learning_rate 0.00018 \
  --train_epochs 4


python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh1.csv \
  --model_id ETTh1_720_192 \
  --model $model_name \
  --data ETTh1 \
  --features S \
  --seq_len 720 \
  --label_len 96 \
  --pred_len 192 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 1 \
  --dec_in 1 \
  --c_out 1 \
  --d_model 48 \
  --d_ff 48 \
  --des 'Exp' \
  --itr 1 \
  --top_k 5 \
  --learning_rate 0.00018 \
  --train_epochs 4


python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh1.csv \
  --model_id ETTh1_720_336 \
  --model $model_name \
  --data ETTh1 \
  --features S \
  --seq_len 720 \
  --label_len 96 \
  --pred_len 336 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 1 \
  --dec_in 1 \
  --c_out 1 \
  --d_model 48 \
  --d_ff 48 \
  --des 'Exp' \
  --itr 1 \
  --top_k 5 \
  --learning_rate 0.00018 \
  --train_epochs 4


python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/ETT-small/ \
  --data_path ETTh1.csv \
  --model_id ETTh1_720_720 \
  --model $model_name \
  --data ETTh1 \
  --features S \
  --seq_len 720 \
  --label_len 96 \
  --pred_len 720 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 1 \
  --dec_in 1 \
  --c_out 1 \
  --d_model 48 \
  --d_ff 48 \
  --des 'Exp' \
  --itr 1 \
  --top_k 5 \
  --learning_rate 0.00018 \
  --train_epochs 4



export CUDA_VISIBLE_DEVICES=4

model_name=TDCNet

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/illness/ \
  --data_path national_illness.csv \
  --model_id ili_60_24 \
  --model $model_name \
  --data custom \
  --features S \
  --seq_len 60 \
  --label_len 24 \
  --pred_len 24 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 1 \
  --dec_in 1 \
  --c_out 1 \
  --d_model 1024 \
  --d_ff 1024 \
  --top_k 5 \
  --des 'Exp' \
  --itr 1\
  --train_epochs 2

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/illness/ \
  --data_path national_illness.csv \
  --model_id ili_60_36 \
  --model $model_name \
  --data custom \
  --features S \
  --seq_len 60 \
  --label_len 24 \
  --pred_len 36 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 1 \
  --dec_in 1 \
  --c_out 1 \
  --d_model 1024 \
  --d_ff 1024 \
  --top_k 5 \
  --des 'Exp' \
  --itr 1\
  --train_epochs 2

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/illness/ \
  --data_path national_illness.csv \
  --model_id ili_60_48 \
  --model $model_name \
  --data custom \
  --features S \
  --seq_len 60 \
  --label_len 24 \
  --pred_len 48 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 1 \
  --dec_in 1 \
  --c_out 1 \
  --d_model 1024 \
  --d_ff 1024 \
  --top_k 5 \
  --des 'Exp' \
  --itr 1\
  --train_epochs 2

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/illness/ \
  --data_path national_illness.csv \
  --model_id ili_60_60 \
  --model $model_name \
  --data custom \
  --features S \
  --seq_len 60 \
  --label_len 24 \
  --pred_len 60 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 1 \
  --dec_in 1 \
  --c_out 1 \
  --d_model 1024 \
  --d_ff 1024 \
  --top_k 5 \
  --des 'Exp' \
  --itr 1\
  --train_epochs 2
import torch.nn as nn
import torch
class series_decomp_v1(nn.Module):
    """
    Series decomposition block with high, middle and low power components
    """

    def __init__(self, high_freq_threshold=0.6, mid_freq_threshold=0.2):
        super(series_decomp_v1, self).__init__()
        self.high_freq_threshold = high_freq_threshold
        self.mid_freq_threshold = mid_freq_threshold

    def forward(self, x):
        batch_size, seq_len, num_channels = x.shape

        # Apply RFFT to entire tensor, keeping dimensions
        xf = torch.fft.rfft(x, dim=1)
        freq = abs(xf)
        freq[:, 0, :] = 0  # Set the DC component to 0

        # Get the maximum frequency for normalization (keeping dimension)
        freq_max = freq.max(dim=1, keepdim=True)[0]

        # High power mask
        high_freq_mask = freq >= self.high_freq_threshold * freq_max
        xf_high = xf.clone()
        xf_high[~high_freq_mask] = 0
        x_high = torch.fft.irfft(xf_high, n=seq_len, dim=1)

        # Middle power mask
        mid_freq_mask = (freq >= self.mid_freq_threshold * freq_max) & (~high_freq_mask)
        xf_mid = xf.clone()
        xf_mid[~mid_freq_mask] = 0
        x_mid = torch.fft.irfft(xf_mid, n=seq_len, dim=1)

        # Low power mask
        low_freq_mask = ~(high_freq_mask | mid_freq_mask)
        xf_low = xf.clone()
        xf_low[~low_freq_mask] = 0
        x_low = torch.fft.irfft(xf_low, n=seq_len, dim=1)

        return x_high, x_mid, x_low
class ResBlock(nn.Module):
    def __init__(self, configs):
        super(ResBlock, self).__init__()

        self.temporal = nn.Sequential(
            nn.Linear(configs.seq_len, configs.d_model),
            nn.ReLU(),
            nn.Linear(configs.d_model, configs.seq_len),
            nn.Dropout(configs.dropout)
        )

        self.channel = nn.Sequential(
            nn.Linear(configs.enc_in, configs.d_model),
            nn.ReLU(),
            nn.Linear(configs.d_model, configs.enc_in),
            nn.Dropout(configs.dropout)
        )

    def forward(self, x):
        # x: [B, L, D]
        x = x + self.temporal(x.transpose(1, 2)).transpose(1, 2)
        x = x + self.channel(x)

        return x


class Model(nn.Module):
    def __init__(self, configs):
        super(Model, self).__init__()
        self.task_name = configs.task_name
        self.layer = configs.e_layers
        self.decompsition = series_decomp_v1(0.6, 0.2)
        self.model = nn.ModuleList([ResBlock(configs)
                                    for _ in range(configs.e_layers)])
        self.pred_len = configs.pred_len
        self.projection = nn.Linear(configs.seq_len, configs.pred_len)

    def forecast(self, x_enc, x_mark_enc, x_dec, x_mark_dec, mask=None):
        x_high, x_mid, x_low = self.decompsition(x_enc)

        for i in range(self.layer):
            x_enc1 = self.model[i](x_high)
        enc_out1 = self.projection(x_enc1.transpose(1, 2)).transpose(1, 2)
        for i in range(self.layer):
            x_enc2 = self.model[i](x_mid)
        enc_out2 = self.projection(x_enc2.transpose(1, 2)).transpose(1, 2)
        for i in range(self.layer):
            x_enc3 = self.model[i](x_low)
        enc_out3 = self.projection(x_enc3.transpose(1, 2)).transpose(1, 2)
        enc_out = enc_out1 + enc_out2 + enc_out3
        
        return enc_out

    def forward(self, x_enc, x_mark_enc, x_dec, x_mark_dec, mask=None):
        if self.task_name == 'long_term_forecast' or self.task_name == 'short_term_forecast':
            dec_out = self.forecast(x_enc, x_mark_enc, x_dec, x_mark_dec)
            return dec_out[:, -self.pred_len:, :]  # [B, L, D]
        else:
            raise ValueError('Only forecast tasks implemented yet')
